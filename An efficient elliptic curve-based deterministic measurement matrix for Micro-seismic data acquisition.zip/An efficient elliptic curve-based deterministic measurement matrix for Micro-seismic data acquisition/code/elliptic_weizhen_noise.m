clear all;
clc;
load biye_weizhenceshiyangben.mat;
load weizhen1024.mat;

load elliptic_sequence_540.mat;

ec=elliptic_sequence_540;

K=100;
L=3;
SNR=20;

PSI=((fft(eye(n))/sqrt(n)))';

e_rand=[];
e_elliptic=[];
e_chao=[];
e_bern=[];
e_peg=[];
e_gmw=[];

for m=140:20:260
    m
 error_elliptic=0;
 error_rand=0;
 error_chao=0;
 error_peg=0;
 error_bern=0;

 d=PEGd(m,n);
Phipeg =myPEGmatrix(m,n,d); 
Phichao=chaos_matrix(m,n);
Phielliptic=Phi_kasami(m,elliptic_sequence_540);
for i=1:1:80
%�����������
Phirand=randn(m,n);
for j=1:n
    Phirand(:,j)=Phirand(:,j)/norm(Phirand(:,j),2);
end
Phibern=BernoulliMtx(m,n);
 %�����ź� 
a=[Demo_weizhen(200:739,(i-1)*3+1)];
b=[Demo_weizhen(200:739,(i-1)*3+2)];
c=[Demo_weizhen(200:739,(i-1)*3+3)];

wz=[a,b,c];
yelliptic=Phielliptic*wz;
    stdnoise = std(reshape(yelliptic,m*L,1))*10^(-SNR/20);
    noise = randn(m,L) * stdnoise;
yrand=Phirand*wz;
    stdnoise = std(reshape(yrand,m*L,1))*10^(-SNR/20);
    noise = randn(m,L) * stdnoise;
ychao=Phichao*wz;
    stdnoise = std(reshape(ychao,m*L,1))*10^(-SNR/20);
    noise = randn(m,L) * stdnoise;
ypeg=Phipeg*wz;
    stdnoise = std(reshape(ypeg,m*L,1))*10^(-SNR/20);
    noise = randn(m,L) * stdnoise;
ybern=Phibern*wz;
    stdnoise = std(reshape(ybern,m*L,1))*10^(-SNR/20);
    noise = randn(m,L) * stdnoise;

theta_elliptic=SOMP(yelliptic,Phielliptic*PSI,K);
theta_rand=SOMP(yrand,Phirand*PSI,K);
theta_chao=SOMP(ychao,Phichao*PSI,K);
theta_peg=SOMP(ypeg,Phipeg*PSI,K);
theta_bern=SOMP(ybern,Phibern*PSI,K);

rec_weizhen_elliptic=real(PSI*theta_elliptic);
rec_weizhen_rand=real(PSI*theta_rand);
rec_weizhen_chao=real(PSI*theta_chao);
rec_weizhen_peg=real(PSI*theta_peg);
rec_weizhen_bern=real(PSI*theta_bern);
rec_weizhen_gmw=real(PSI*theta_gmw);

error_elliptic=error_elliptic+norm(rec_weizhen_elliptic-wz,2)/norm(wz,2);
error_rand=error_rand+norm(rec_weizhen_rand-wz,2)/norm(wz,2);
error_chao=error_chao+norm(rec_weizhen_chao-wz,2)/norm(wz,2);
error_peg=error_peg+norm(rec_weizhen_peg-wz,2)/norm(wz,2);
error_bern=error_bern+norm(rec_weizhen_bern-wz,2)/norm(wz,2);
error_gmw=error_gmw+norm(rec_weizhen_gmw-wz,2)/norm(wz,2);
m
i 
end
e_elliptic=[e_elliptic,error_elliptic/i];
e_rand=[e_rand,error_rand/i];
e_chao=[e_chao,error_chao/i];
e_peg=[e_peg,error_peg/i];
e_bern=[e_bern,error_bern/i];
e_gmw=[e_gmw,error_gmw/i];
end
figure;
plot(e_elliptic,'r');hold on;
plot(e_rand,'b');hold on;
plot(e_chao,'g');hold on;
plot(e_peg,'y');hold on;
plot(e_bern,'k');hold on;