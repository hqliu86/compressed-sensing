function[Phi_kasa]=Phi_kasami(M,kasa1)

for i=1:1:length(kasa1)
    Phi_kasa1(:,i)=circshift(kasa1,[0,i-1]);
end
a=diag(kasa1);
Index_K = randperm(length(kasa1));
Phi_kasa=Phi_kasa1(sort(Index_K(1:M)),1:length(kasa1));
end




