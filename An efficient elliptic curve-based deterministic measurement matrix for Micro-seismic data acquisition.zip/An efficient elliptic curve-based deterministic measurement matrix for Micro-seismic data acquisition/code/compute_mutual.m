clear all;
close all;
clc;  
load elliptic_sequence_407.mat;
load elliptic_sequence_540.mat;
load elliptic_sequence_1150.mat;
[ec]=compute_elliptic_dian(211,220);
%[ec]=compute_elliptic_dian(257,255);
U_vectorBIBD=[];
U_vectorPEG=[];
U_vectorRand=[];
U_vectorRand_sparse=[];
U_vectorGMW_eye=[];
U_vectorGMW_fourier=[];
U_vectorGMW_dct=[];

U_vectorPEG_eye=[];
U_vectorPEG_fourier=[];
U_vectorPEG_dct=[];

U_vectorRand_eye=[];
U_vectorRand_fourier=[];
U_vectorRand_dct=[];

U_vectorRands_eye=[];
U_vectorRands_fourier=[];
U_vectorRands_dct=[];
n=length(ec);
for M=5:10:n-10
M
U_max_rand=0;
U_max_rands=0;
U_max_chaos=0;
 %������Բ���߹۲����
     Phigmw=Phi_kasami(M,ec);
    [M,N]=size(Phigmw);
   %ϡ���    
      PSI=(fft(eye(N))/sqrt(N))';   
    %  PSI=eye(N);
%GMW�۲����
        Phigmw=Phigmw;
        C=Phigmw;
  A=Phigmw*PSI;
  B=A;
for i=1:n
    B(:,i)=A(:,i)/norm(A(:,i),2);
end
for i=1:n
    for j=1:n
        if i==j
            C(i,j)=0;
        else
        C(i,j)=abs(A(:,i)'*A(:,j))/norm(A(:,i),2);
       C(i,j)=C(i,j)/ norm(A(:,j),2);
        end
    end
end

U=B'*B;
[m,n]=size(U);
for i=1:m
    U(i,i)=0;
end
U_max=max(max(real(U))) ;

 U_vectorGMW_fourier=[U_vectorGMW_fourier,U_max];

 %����۲���� 
for ii=1:1:500
   Phi_chaos=chaos_matrix(M,N);
A=Phi_chaos*PSI;
[m,n]=size(A);
for i=1:n
    B(:,i)=A(:,i)/norm(A(:,i),2);
end
for i=1:n
    for j=1:n
        if i==j
            C(i,j)=0;
        else
        C(i,j)=abs(A(:,i)'*A(:,j))/norm(A(:,i),2);
       C(i,j)=C(i,j)/ norm(A(:,j),2);
        end
    end
end
U=B'*B;
[m,n]=size(U);
for i=1:m
    U(i,i)=0;
end
U_max_chaos=U_max_chaos+max(max(abs(real(U)))) ;
end

 U_vectorPEG_fourier=[U_vectorPEG_fourier,U_max_chaos/ii];

%���ϡ��
for ii=1:1:500
    Phi_rands = zeros(M,N);  
   for iii = 1:N  
       ColIdx = randperm(M);  
        Phi_rands(ColIdx(1:4),iii) = 1;  
   end
   Phi_rands=Phi_rands;
A=Phi_rands*PSI;
for i=1:n
    B(:,i)=A(:,i)/norm(A(:,i),2);
end
for i=1:n
    for j=1:n
        if i==j
            C(i,j)=0;
        else
        C(i,j)=abs(A(:,i)'*A(:,j))/norm(A(:,i),2);
       C(i,j)=C(i,j)/ norm(A(:,j),2);
        end
    end
end

U=B'*B;
[m,n]=size(U);
for i=1:m
    U(i,i)=0;
end
U_max_rands=U_max_rands+max(max(abs(real(U))));
  end

 U_vectorRands_fourier=[U_vectorRands_fourier,U_max_rands/ii];

%��˹���
 for ii=1:1:500
  Phi_rand = randn(M,N);%��������Ϊ��˹����
  [m,n]=size(Phi_rand);
for i=1:n
    Phi_rand(:,i)=Phi_rand(:,i)/norm(Phi_rand(:,i),2);
end
A=Phi_rand*PSI;
[m,n]=size(A);
for i=1:n
    B(:,i)=A(:,i)/norm(A(:,i),2);
end
U=B'*B;
[m,n]=size(U);
for i=1:m
    U(i,i)=0;
end

U_max_rand=U_max_rand+max(max(abs(real(U)))) ;

 end
 U_vectorRand_fourier=[U_vectorRand_fourier,U_max_rand/ii];

end
a=5:10:length(ec)-10
figure ;
plot(a,U_vectorPEG_fourier,'gs:');
hold on;
 plot(a,U_vectorRands_fourier,'bd:');
 hold on;
plot(a,U_vectorRand_fourier,'m>:');
hold on;
plot(a,U_vectorGMW_fourier,'ro:');
xlabel('�۲���');
ylabel('�����ϵ��')
legend('����۲����','���ϡ��۲����','��˹����۲����','�Ľ�GMW�۲����');

